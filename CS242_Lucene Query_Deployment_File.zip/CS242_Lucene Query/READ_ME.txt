1) Retrieve the Indexer files from https://drive.google.com/open?id=1ASFELsopw6PJzur_0SLN6y7guvgZeRHL.

2) Place the files into the "Index_Files" folder (the folder is currently empty).

3) Run lucene_query.bat on command line.
	Note: there are two ways you can run it
	Option 1: "lucene_query.bat [number of hits to display] [query]"
		You can type the number of hits to display and the query on the same line as the run 
 		without brackets:
	Option 2: "lucene_query.bat"
		You can run without parameters and the program will request for them afterwards.